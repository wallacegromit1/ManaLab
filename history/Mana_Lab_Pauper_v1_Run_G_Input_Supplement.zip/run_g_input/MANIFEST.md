# Run G supplement manifest

This bundle contains:
- the Run G execution prompt;
- Mana Lab Pauper v1 core specification files;
- Strixpatch Affinity v1.3 benchmark definition;
- prior audit/model-risk context;
- Run C supporting evidence reconstructed from archived project files;
- Run F failure brief;
- exact Run E parent filename/hash requirement.

It intentionally does not contain the production Run E repository ZIP. The execution environment must also receive the exact `Mana_Lab_Pauper_v1_Run_E.zip` with SHA-256 `82d1dcd663de5a8bcb2d9917271fba264c509bdff8b45d1920b9f97ccf0d0c71`.
