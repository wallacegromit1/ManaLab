# Mana Lab — Run G input supplement

Purpose: supporting packet for **Run G — Phase 3 Readiness Remediation Implementation + Revalidation**.

## Required execution inputs
1. **Exact production parent:** `Mana_Lab_Pauper_v1_Run_E.zip`
   - SHA-256: `82d1dcd663de5a8bcb2d9917271fba264c509bdff8b45d1920b9f97ccf0d0c71`
2. This supplement ZIP.
3. Full Run F audit files if available in the same Work/project workspace.

This supplement intentionally does **not** contain the Run E production ZIP because that archive is not mounted in the current chat runtime. It must not be replaced by Run C or reconstructed from specs.

## Scope
Run G repairs Phase-3 readiness only. No candidate screening, ranking, optimization, frontier construction, or recommendation is authorized.
