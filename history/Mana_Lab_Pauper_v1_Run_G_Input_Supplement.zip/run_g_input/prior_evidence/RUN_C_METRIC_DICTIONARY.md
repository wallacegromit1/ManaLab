# Run C metric dictionary — summary

Raw events are authoritative. Aggregate objective weights were intentionally absent in Run C.

Configured metric families included:
- opening land distribution;
- mulligan count / kept hand size;
- usable untapped mana by turn;
- W/U/B/R access and joint UB access by turn;
- spell-level on-time castability and stranded-spell reasons;
- opponent-turn interaction availability;
- full-effect Metalcraft interaction availability;
- double-spell and spell+held-interaction success;
- artifact count and Metalcraft rate;
- affinity reduction;
- Boulder deploy/activation/rescue/dependency;
- Cryogen enter/leave draw events;
- Glint Hawk execution/return/replay cost;
- Bargain execution/sacrifice resource loss;
- critical-sequence success;
- realized ETB-tapped blocks;
- unused and unavailable tapped mana;
- Blood/Nihil/Munitions/Cryogen-stun option events;
- scry outcomes;
- land return/sacrifice events.

Run C reported 29 configured metrics with 0 missing definitions. The full Run E repository is authoritative for the current event schema.
