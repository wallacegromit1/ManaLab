# Mana Lab — Pauper v1 Run C validation report

## Executive result

### `RUN C IMPLEMENTATION — READY FOR INDEPENDENT QA`

Run C repaired and revalidated the measurement engine. It did not simulate the legal candidate space for performance, rank candidates, construct a frontier, or recommend a mana base. Phase 3 remained unauthorized pending independent QA.

## Implemented patches

| Patch | Run B finding | Status |
|---|---|---|
| P1 | Causal/no-lookahead action search | PASS |
| P2 | First-valid payment/search-order dependence | PASS |
| P3 | Individually-castable land shortcut | PASS |
| P4 | Forced land-before-spell sequencing | PASS |
| P5 | Boulder/Bargain/opponent-window gaps | PASS |
| P6 | Boulder scry semantic mismatch | PASS |
| P7 | Additive reserve proxy | PASS |
| P8 | Incomplete Phase-3 event schema | PASS |
| P9 | Limited production-policy smoke | PASS |

## Validation

- Full unit suite reported by Run C: **133 passed, 0 failed, 0 skipped**.
- Separate no-lookahead execution: **18 passed, 0 failed**.
- Frozen deck: **60 cards / 41 nonlands / 19 lands / four Giant's Boulders**.
- Candidate enumeration: **296,706**; independent DP: **296,706**; C0 occurrences: **1**.
- Minimum Bridges: **3**; three-Bridge class: **56**.
- T2 Myr Enforcer relaxed impossibility fixture: **PASS**.
- Metric contract: **PASS** for every configured primary/secondary metric.
- Independent seed partition: **PASS**.
- Cheap engine exact-vs-simulation smoke: **PASS** at **20,000** raw sevens.
- Same-config/seed reproducibility rerun: **PASS**.

## Remaining limitations at Run C

- Opponent behavior and target arrival probabilities unspecified; interaction therefore raw counterfactual resource metric.
- Target-dependent late Boulder, Cryogen stun, Munitions, Blood, and Nihil choices require explicit fixtures and were not assigned speculative value.
- Own-main planner bounded to depth 8 (12 executed replans), validated for frozen turn-1–4 benchmark only.
- Desired timing profiles and baseline/alternate heuristics are subjective frozen assumptions, not empirical play-rate claims.
- Production smoke is machinery validation, not a precision performance experiment.
