# Required production parent for Run G

Run G must patch the exact package independently audited by Run F:

- File: `Mana_Lab_Pauper_v1_Run_E.zip`
- SHA-256: `82d1dcd663de5a8bcb2d9917271fba264c509bdff8b45d1920b9f97ccf0d0c71`
- Known Run E validation state: 179 tests passed; D-01 through D-11 regressions passed; legal candidate count 296,706; implementation gate passed; package was submitted to Run F for independent Phase 3 authorization.

The production Run E ZIP itself is NOT embedded in this supplement because it is not mounted in the current chat runtime. Do not silently substitute Run C or rebuild the repository from these source specifications.

If the exact Run E ZIP is unavailable in the execution environment, stop with `INPUT BLOCKED — EXACT RUN E PARENT MISSING`.
