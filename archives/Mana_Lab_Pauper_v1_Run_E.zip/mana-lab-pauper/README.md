# Mana Lab — Pauper v1 — Run E

Mana Lab is a reproducible Pauper mana-base simulation and validation engine. This repository contains the Run E remediation of the frozen Strixpatch Affinity v1.3 benchmark.

## Current phase

**Run E: remediation and revalidation only.** The program enumerates the full legal candidate space only to verify its exact size and invariants. It does not simulate that space for performance, screen candidates, select finalists, build a Pareto frontier, or recommend a mana base.

Run E runs deterministic regressions, horizon and information-value sensitivity, and a compact production-policy smoke for protected fixtures. These are explicitly non-ranking diagnostics.

## Quick start

Python 3.11+ and PyYAML 6+ are required.

```bash
export PYTHONPATH="$PWD/src"
python -m unittest discover -s tests -v
python -m mana_lab.cli run-e
```

The concise result is `RUN_E_VALIDATION_REPORT.md`. Auditable files are written under `outputs/run_e/`.

## Architecture

- `cards.py`: machine-readable deck, card, and land contracts
- `state.py`: physical cards, zones, permanents, stack, turn/phase state
- `mana.py` / `payment.py`: explicit payment, conservation, affinity, and filtering
- `effects.py`: scry, draw, triggers, returns, sacrifices, and token state
- `policies.py` / `mulligan.py`: executable named policies with visible-state boundaries
- `simulator.py`: causal visible-state planning plus deterministic/pairable validation simulation
- `candidates.py`: exact legal enumeration and independent DP count
- `statistics.py` / `metrics.py`: exact checks, uncertainty helpers, and raw event preservation
- `run_e_validation.py`: staged Run E gate, reports, robustness checks, and hard stop

## Phase gate

`Strixpatch_Affinity_v1.3.experiment.yaml` has `optimization_execution_allowed: false`. `run-c` refuses an optimization-enabled configuration. No command in this repository performs candidate scoring or selection.

Run E may declare readiness for independent authorization, but another short independent audit is recommended before expensive Phase 3 work.
